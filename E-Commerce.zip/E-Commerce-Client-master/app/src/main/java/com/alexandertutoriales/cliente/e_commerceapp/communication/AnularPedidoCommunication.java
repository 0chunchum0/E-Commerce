package com.alexandertutoriales.cliente.e_commerceapp.communication;

public interface AnularPedidoCommunication {
    String anularPedido(int id);
}
