package com.alexandertutoriales.cliente.e_commerceapp.communication;

import com.alexandertutoriales.cliente.e_commerceapp.entity.service.DetallePedido;

public interface MostrarBadgeCommunication {
    void add(DetallePedido dp);
}
