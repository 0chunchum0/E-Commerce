package com.alexandertutoriales.cliente.e_commerceapp.communication;

public interface CarritoCommunication {
    void eliminarDetalle(int idP);
}
